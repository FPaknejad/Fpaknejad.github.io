#include <iostream>

int main() {
    std::cout << "Project is ready.\n";
    return 0;
}
