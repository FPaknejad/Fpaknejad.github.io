#include <iostream>

int main() {
    std::cout << "Running tests...\n";
    return 0;
}
