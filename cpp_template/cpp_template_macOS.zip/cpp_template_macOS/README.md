# Universal C++20 Template
This template supports:
- C++20
- Modules (.cppm)
- Classic OOP (.cpp/.hpp)
- Unit Tests
- macOS Clang
- CMake
- VS Code integration

## Build